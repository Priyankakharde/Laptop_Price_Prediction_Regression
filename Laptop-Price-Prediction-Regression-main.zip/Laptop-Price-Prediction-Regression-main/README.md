# Laptop-Price-Prediction-Regression
This is an repo that helps out students and other person to choose the best laptop by predicting the price according to the features of laptop
